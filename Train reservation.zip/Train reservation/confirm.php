<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['booking'])) header('Location: login.php');
include 'db.php';

$booking = $_SESSION['booking'];
$user_id = $_SESSION['user_id'];

// Verify user exists
$user_check = $conn->query("SELECT id FROM users WHERE id=$user_id");
if ($user_check->num_rows == 0) {
    session_destroy();
    header('Location: login.php?error=user_not_found');
    exit();
}

$sql = "SELECT * FROM trains WHERE id={$booking['train_id']}";
$train = $conn->query($sql)->fetch_assoc();
$total_price = $booking['seats'] * $train['price'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Insert booking
    $conn->query("INSERT INTO bookings (user_id, train_id, seats_booked, total_price) VALUES ($user_id, {$booking['train_id']}, {$booking['seats']}, $total_price)");
    $booking_id = $conn->insert_id;
    
    // Insert passengers
    foreach ($booking['passengers'] as $passenger) {
        $conn->query("INSERT INTO passengers (booking_id, name, age, gender) VALUES ($booking_id, '{$passenger['name']}', {$passenger['age']}, '{$passenger['gender']}')");
    }
    
    // Update seats
    $conn->query("UPDATE trains SET seats_available = seats_available - {$booking['seats']} WHERE id={$booking['train_id']}");
    
    unset($_SESSION['booking']);
    header('Location: bookings.php?success=1');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php"><i class="bi bi-train-front"></i> Railway Reservation</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="nav-link" href="search.php">Search Trains</a></li>
                        <li class="nav-item"><a class="nav-link" href="bookings.php">My Bookings</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5 pt-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header text-center bg-success text-white">
                        <h2><i class="bi bi-check-circle"></i> Confirm Your Booking</h2>
                    </div>
                    <div class="card-body">
                        <h4 class="text-primary">Train Details</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Train Number:</strong> <?php echo $train['id']; ?></p>
                                <p><strong>Train Name:</strong> <?php echo $train['name']; ?></p>
                                <p><strong>Source:</strong> <?php echo $train['source']; ?></p>
                                <p><strong>Destination:</strong> <?php echo $train['destination']; ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Date:</strong> <?php echo date('d M Y', strtotime($train['date'])); ?></p>
                                <p><strong>Departure Time:</strong> <?php echo $train['departure_time']; ?></p>
                                <p><strong>Arrival Time:</strong> <?php echo $train['arrival_time']; ?></p>
                                <p><strong>Price per Seat:</strong> ₹<?php echo $train['price']; ?></p>
                            </div>
                        </div>
                        
                        <hr>
                        <h4 class="text-primary">Passenger Details</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Age</th>
                                        <th>Gender</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 1; foreach ($booking['passengers'] as $passenger): ?>
                                        <tr>
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo $passenger['name']; ?></td>
                                            <td><?php echo $passenger['age']; ?></td>
                                            <td><?php echo $passenger['gender']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <hr>
                        <h4 class="text-primary">Booking Summary</h4>
                        <div class="row">
                            <div class="col-md-6">
                                <p><strong>Number of Seats:</strong> <?php echo $booking['seats']; ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Total Price:</strong> ₹<?php echo $total_price; ?></p>
                            </div>
                        </div>
                        
                        <div class="text-center mt-4">
                            <form method="post" class="d-inline">
                                <button type="submit" class="btn btn-success btn-lg"><i class="bi bi-check-circle"></i> Confirm Booking</button>
                            </form>
                            <a href="book.php?train_id=<?php echo $booking['train_id']; ?>" class="btn btn-secondary btn-lg ms-2"><i class="bi bi-arrow-left"></i> Back to Edit</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>