<?php
session_start();
if (!isset($_SESSION['user_id'])) header('Location: login.php');
include 'db.php';

$user_id = $_SESSION['user_id'];
$sql = "SELECT b.*, t.name, t.source, t.destination, t.date, t.departure_time, t.arrival_time FROM bookings b JOIN trains t ON b.train_id = t.id WHERE b.user_id=$user_id ORDER BY b.booking_date DESC";
$result = $conn->query($sql);
$bookings = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Bookings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php"><i class="bi bi-train-front"></i> Railway Reservation</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="nav-link" href="search.php">Search Trains</a></li>
                        <li class="nav-item"><a class="nav-link" href="bookings.php">My Bookings</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5 pt-4">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header text-center">
                        <h2><i class="bi bi-list"></i> My Bookings</h2>
                    </div>
                    <div class="card-body">
                        <?php if (isset($_GET['success'])): ?>
                            <div class="alert alert-success">Booking confirmed successfully!</div>
                        <?php endif; ?>
                        <?php if ($bookings): ?>
                            <?php foreach ($bookings as $booking): ?>
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h5><?php echo $booking['name']; ?> (Train No: <?php echo $booking['train_id']; ?>)</h5>
                                        <p><strong>Route:</strong> <?php echo $booking['source']; ?> to <?php echo $booking['destination']; ?></p>
                                        <p><strong>Date:</strong> <?php echo date('d M Y', strtotime($booking['date'])); ?> | <strong>Departure:</strong> <?php echo $booking['departure_time']; ?> | <strong>Arrival:</strong> <?php echo $booking['arrival_time']; ?></p>
                                        <p><strong>Seats Booked:</strong> <?php echo $booking['seats_booked']; ?> | <strong>Total Price:</strong> ₹<?php echo $booking['total_price']; ?></p>
                                        <p><strong>Booked On:</strong> <?php echo date('d M Y, H:i', strtotime($booking['booking_date'])); ?></p>
                                        
                                        <!-- Display Passengers -->
                                        <?php
                                        $booking_id = $booking['id'];
                                        $passenger_sql = "SELECT * FROM passengers WHERE booking_id=$booking_id";
                                        $passenger_result = $conn->query($passenger_sql);
                                        $passengers = $passenger_result->fetch_all(MYSQLI_ASSOC);
                                        if ($passengers): ?>
                                            <h6>Passengers:</h6>
                                            <ul class="list-group list-group-flush">
                                                <?php foreach ($passengers as $passenger): ?>
                                                    <li class="list-group-item"><?php echo $passenger['name']; ?> (Age: <?php echo $passenger['age']; ?>, Gender: <?php echo $passenger['gender']; ?>)</li>
                                                <?php endforeach; ?>
                                            </ul>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-muted">No bookings found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>