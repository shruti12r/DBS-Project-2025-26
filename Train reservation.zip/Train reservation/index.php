<?php
session_start();
include 'db.php';

$bookings = [];
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT b.*, t.name, t.source, t.destination, t.date, t.departure_time, t.arrival_time FROM bookings b JOIN trains t ON b.train_id = t.id WHERE b.user_id=$user_id ORDER BY b.booking_date DESC";
    $result = $conn->query($sql);
    $bookings = $result->fetch_all(MYSQLI_ASSOC);
}

// Function to check if train has departed
function isDeparted($train_date, $departure_time) {
    $current_datetime = date('Y-m-d H:i:s');
    $train_datetime = $train_date . ' ' . $departure_time;
    return strtotime($train_datetime) < strtotime($current_datetime);
}

// Fetch available trains (seats > 0, date >= today, and not departed)
$sql_trains = "SELECT * FROM trains WHERE seats_available > 0 AND date >= CURDATE() ORDER BY date ASC";
$result_trains = $conn->query($sql_trains);
$all_trains = $result_trains->fetch_all(MYSQLI_ASSOC);
$trains = [];
foreach ($all_trains as $train) {
    if (!isDeparted($train['date'], $train['departure_time'])) {
        $trains[] = $train;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Railway Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php"><i class="bi bi-train-front"></i> Railway Reservation</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="nav-link" href="search.php">Search Trains</a></li>
                        <li class="nav-item"><a class="nav-link" href="bookings.php">My Bookings</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5 pt-4">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h1 class="card-title"><i class="bi bi-house-door"></i> Welcome to Railway Reservation System</h1>
                        <p class="card-text">Book your train tickets easily and securely.</p>
                        <?php if (!isset($_SESSION['user_id'])): ?>
                            <a href="register.php" class="btn btn-primary me-2"><i class="bi bi-person-plus"></i> Get Started</a>
                            <a href="login.php" class="btn btn-outline-primary"><i class="bi bi-box-arrow-in-right"></i> Login</a>
                        <?php else: ?>
                            <a href="search.php" class="btn btn-success"><i class="bi bi-search"></i> Search Trains</a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Available Trains Section -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h3><i class="bi bi-train"></i> Available Trains</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($trains): ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Train No.</th>
                                            <th>Train Name</th>
                                            <th>Route</th>
                                            <th>Date</th>
                                            <th>Departure</th>
                                            <th>Arrival</th>
                                            <th>Seats Available</th>
                                            <th>Price (₹)</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($trains as $train): ?>
                                            <tr>
                                                <td><?php echo $train['id']; ?></td>
                                                <td><?php echo $train['name']; ?></td>
                                                <td><?php echo $train['source']; ?> to <?php echo $train['destination']; ?></td>
                                                <td><?php echo date('d M Y', strtotime($train['date'])); ?></td>
                                                <td><?php echo $train['departure_time']; ?></td>
                                                <td><?php echo $train['arrival_time']; ?></td>
                                                <td><?php echo $train['seats_available']; ?></td>
                                                <td><?php echo $train['price']; ?></td>
                                                <td>
                                                    <?php if (isset($_SESSION['user_id'])): ?>
                                                        <a href="book.php?train_id=<?php echo $train['id']; ?>" class="btn btn-sm btn-success"><i class="bi bi-ticket"></i> Book</a>
                                                    <?php else: ?>
                                                        <a href="login.php" class="btn btn-sm btn-outline-success"><i class="bi bi-box-arrow-in-right"></i> Login</a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No available trains at the moment.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3><i class="bi bi-check-circle"></i> Your Confirmed Trains</h3>
                        </div>
                        <div class="card-body">
                            <?php if ($bookings): ?>
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Train No.</th>
                                                <th>Train Name</th>
                                                <th>Route</th>
                                                <th>Date</th>
                                                <th>Departure</th>
                                                <th>Arrival</th>
                                                <th>Seats Booked</th>
                                                <th>Total Price</th>
                                                <th>Booked On</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($bookings as $booking): ?>
                                                <tr>
                                                    <td><?php echo $booking['train_id']; ?></td>
                                                    <td><?php echo $booking['name']; ?></td>
                                                    <td><?php echo $booking['source']; ?> to <?php echo $booking['destination']; ?></td>
                                                    <td><?php echo date('d M Y', strtotime($booking['date'])); ?></td>
                                                    <td><?php echo $booking['departure_time']; ?></td>
                                                    <td><?php echo $booking['arrival_time']; ?></td>
                                                    <td><?php echo $booking['seats_booked']; ?></td>
                                                    <td>₹<?php echo $booking['total_price']; ?></td>
                                                    <td><?php echo date('d M Y, H:i', strtotime($booking['booking_date'])); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">No confirmed bookings yet. <a href="search.php">Search for trains</a> to make your first booking!</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>