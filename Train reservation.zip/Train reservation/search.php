<?php
session_start();
if (!isset($_SESSION['user_id'])) header('Location: login.php');
include 'db.php';

$trains = [];
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $source = $_POST['source'];
    $destination = $_POST['destination'];
    $date = $_POST['date'];
    
    $sql = "SELECT * FROM trains WHERE source='$source' AND destination='$destination' AND date='$date'";
    $result = $conn->query($sql);
    $trains = $result->fetch_all(MYSQLI_ASSOC);
    if (empty($trains)) $message = '<div class="alert alert-warning">No trains found for the selected route and date.</div>';
}

// Function to check if train has departed
function isDeparted($train_date, $departure_time) {
    $current_datetime = date('Y-m-d H:i:s');
    $train_datetime = $train_date . ' ' . $departure_time;
    return strtotime($train_datetime) < strtotime($current_datetime);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Trains</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php"><i class="bi bi-train-front"></i> Railway Reservation</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="nav-link" href="search.php">Search Trains</a></li>
                        <li class="nav-item"><a class="nav-link" href="bookings.php">My Bookings</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5 pt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h2><i class="bi bi-search"></i> Search Trains</h2>
                    </div>
                    <div class="card-body">
                        <form method="post" class="row g-3">
                            <div class="col-md-4">
                                <label for="source" class="form-label">Source</label>
                                <input type="text" class="form-control" id="source" name="source" required>
                            </div>
                            <div class="col-md-4">
                                <label for="destination" class="form-label">Destination</label>
                                <input type="text" class="form-control" id="destination" name="destination" required>
                            </div>
                            <div class="col-md-4">
                                <label for="date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="date" name="date" required>
                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Search</button>
                            </div>
                        </form>
                        <?php echo $message; ?>
                        <?php if ($trains): ?>
                            <div class="table-responsive mt-4">
                                <table class="table table-striped table-hover">
                                    <thead class="table-dark">
                                        <tr>
                                            <th>Train No.</th>
                                            <th>Train Name</th>
                                            <th>Source</th>
                                            <th>Destination</th>
                                            <th>Date</th>
                                            <th>Departure</th>
                                            <th>Arrival</th>
                                            <th>Seats</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($trains as $train): 
                                            $departed = isDeparted($train['date'], $train['departure_time']);
                                            $status = $departed ? 'Departed' : 'Available';
                                            $status_class = $departed ? 'text-danger' : 'text-success';
                                        ?>
                                            <tr>
                                                <td><?php echo $train['id']; ?></td>
                                                <td><?php echo $train['name']; ?></td>
                                                <td><?php echo $train['source']; ?></td>
                                                <td><?php echo $train['destination']; ?></td>
                                                <td><?php echo date('d M Y', strtotime($train['date'])); ?></td>
                                                <td><?php echo $train['departure_time']; ?></td>
                                                <td><?php echo $train['arrival_time']; ?></td>
                                                <td><?php echo $train['seats_available']; ?></td>
                                                <td>₹<?php echo $train['price']; ?></td>
                                                <td class="<?php echo $status_class; ?>"><strong><?php echo $status; ?></strong></td>
                                                <td>
                                                    <?php if (!$departed): ?>
                                                        <a href="book.php?train_id=<?php echo $train['id']; ?>" class="btn btn-sm btn-success"><i class="bi bi-ticket"></i> Book</a>
                                                    <?php else: ?>
                                                        <button class="btn btn-sm btn-secondary" disabled><i class="bi bi-x-circle"></i> Departed</button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>