<?php
session_start();
if (!isset($_SESSION['user_id'])) header('Location: login.php');
include 'db.php';

$train_id = $_GET['train_id'];
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM trains WHERE id=$train_id";
$train = $conn->query($sql)->fetch_assoc();

$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $seats = $_POST['seats'];
    if ($seats > $train['seats_available']) {
        $message = '<div class="alert alert-danger">Not enough seats available.</div>';
    } else {
        // Store in session for confirmation
        $_SESSION['booking'] = [
            'train_id' => $train_id,
            'seats' => $seats,
            'passengers' => []
        ];
        for ($i = 1; $i <= $seats; $i++) {
            $_SESSION['booking']['passengers'][] = [
                'name' => $_POST["name_$i"],
                'age' => $_POST["age_$i"],
                'gender' => $_POST["gender_$i"]
            ];
        }
        header('Location: confirm.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Ticket</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
        <!-- Same navbar -->
    </nav>

    <div class="container mt-5 pt-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h2><i class="bi bi-ticket"></i> Book Ticket</h2>
                    </div>
                    <div class="card-body">
                        <h4>Train Details</h4>
                        <p><strong>Train No:</strong> <?php echo $train['id']; ?> | <strong>Name:</strong> <?php echo $train['name']; ?></p>
                        <p><strong>Route:</strong> <?php echo $train['source']; ?> to <?php echo $train['destination']; ?> | <strong>Date:</strong> <?php echo date('d M Y', strtotime($train['date'])); ?></p>
                        <p><strong>Departure:</strong> <?php echo $train['departure_time']; ?> | <strong>Arrival:</strong> <?php echo $train['arrival_time']; ?> | <strong>Price:</strong> ₹<?php echo $train['price']; ?> per seat</p>
                        <p><strong>Seats Available:</strong> <?php echo $train['seats_available']; ?></p>
                        
                        <?php echo $message; ?>
                        <form method="post">
                            <div class="mb-3">
                                <label for="seats" class="form-label">Number of Seats</label>
                                <input type="number" class="form-control" id="seats" name="seats" min="1" max="<?php echo $train['seats_available']; ?>" required onchange="generatePassengerFields(this.value)">
                            </div>
                            <div id="passenger-fields"></div>
                            <button type="submit" class="btn btn-primary"><i class="bi bi-check-circle"></i> Proceed to Confirm</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function generatePassengerFields(seats) {
            const container = document.getElementById('passenger-fields');
            container.innerHTML = '';
            for (let i = 1; i <= seats; i++) {
                container.innerHTML += `
                    <h5>Passenger ${i}</h5>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="name_${i}" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name_${i}" name="name_${i}" required>
                        </div>
                        <div class="col-md-4">
                            <label for="age_${i}" class="form-label">Age</label>
                            <input type="number" class="form-control" id="age_${i}" name="age_${i}" min="1" required>
                        </div>
                        <div class="col-md-4">
                            <label for="gender_${i}" class="form-label">Gender</label>
                            <select class="form-control" id="gender_${i}" name="gender_${i}" required>
                                <option value="">Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>
                `;
            }
        }
    </script>
</body>
</html>